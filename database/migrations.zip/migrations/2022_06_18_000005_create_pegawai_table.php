<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePegawaiTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pegawai', function (Blueprint $table) {
            $table->bigIncrements('id')->unsigned();
            $table->string('nip',20);
            $table->string('nama');
            $table->date('tgl_lahir');
            $table->tinyInteger('pendidikan');
            $table->string('gender',1);
            $table->bigInteger('id_jabatan')->unsigned()->nullable();
            $table->bigInteger('id_upt')->unsigned()->nullable();
            $table->bigInteger('id_wilayah')->unsigned()->nullable();
            $table->bigInteger('id_atasan')->unsigned()->nullable();
            $table->foreign('id_jabatan')->references('id')->on('jabatan')->onDelete('CASCADE');
            $table->foreign('id_upt')->references('id')->on('upt')->onDelete('CASCADE');
            $table->foreign('id_wilayah')->references('id')->on('wilayah')->onDelete('CASCADE');
            $table->foreign('id_atasan')->references('id')->on('pegawai')->onDelete('CASCADE');
            $table->string('no_telp',15);
            $table->text('alamat');
            $table->string('foto');
            $table->boolean('status_pegawai')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pegawai');
    }
}
